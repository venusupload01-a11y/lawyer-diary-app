﻿const storageKey = "lawyers-diary-data-v1";

const requiredOrderDocuments = [
  {
    date: "2025-01-09",
    details: "Maintenance Order",
    attachment: { label: "Maintenenace Order 09012025.pdf", path: "attachments/Maintenenace Order 09012025.pdf" }
  },
  {
    date: "2025-02-15",
    details: "Application - Distrace Warrant",
    attachment: { label: "Application - Distrace Warrant 15022025.pdf", path: "attachments/Application - Distrace Warrant 15022025.pdf" }
  },
  {
    date: "2025-03-15",
    details: "Bailable Warrant Issuance Application",
    attachment: { label: "Bailabale Warrant Issuance Application 15032025.pdf", path: "attachments/Bailabale Warrant Issuance Application 15032025.pdf" }
  },
  {
    date: "2025-03-18",
    details: "Issue NBW",
    attachment: { label: "Issue NBW 18032025.pdf", path: "attachments/Issue NBW 18032025.pdf" }
  },
  {
    date: "2025-03-20",
    details: "Application for Arrest Warrant",
    attachment: { label: "Application for Arrest Warrant 20032025.pdf", path: "attachments/Application for Arrest Warrant 20032025.pdf" }
  },
  {
    date: "2025-05-02",
    details: "Arrest Warrant Issue",
    attachment: { label: "Arrest Warrant Issue 02052025.pdf", path: "attachments/Arrest Warrant Issue 02052025.pdf" }
  },
  {
    date: "2025-06-02",
    details: "Arrest Warrant Against Respondent",
    attachment: { label: "Arrest Warrant against Respondent 02062025.pdf", path: "attachments/Arrest Warrant against Respondent 02062025.pdf" }
  },
  {
    date: "2025-10-29",
    details: "Application Allowed As Prayed",
    attachment: { label: "Application allowed as prayed 29102025.pdf", path: "attachments/Application allowed as prayed 29102025.pdf" }
  }
];

const requiredReferenceJudgements = [
  {
    id: "ref-rajnesh-neha",
    title: "Rajnesh v. Neha",
    citation: "Supreme Court of India | Criminal Appeal No. 730 of 2020 | 04 Nov 2020",
    attachment: { label: "Rajnesh_vs_Neha_2020.pdf", path: "references/Rajnesh_vs_Neha_2020.pdf" }
  },
  {
    id: "ref-aditi-jitesh-2023",
    title: "Aditi alias Mithi v. Jitesh Sharma",
    citation: "2023 INSC 981 | Criminal Appeal No. 3446 of 2023 | 06 Nov 2023",
    attachment: {
      label: "Aditi_alias_Mithi_vs_Jitesh_Sharma_2023_INSC_981.pdf",
      path: "references/Aditi_alias_Mithi_vs_Jitesh_Sharma_2023_INSC_981.pdf"
    }
  },
  {
    id: "ref-arnesh-bihar",
    title: "Arnesh Kumar v. State of Bihar",
    citation: "Supreme Court of India | Criminal Appeal No. 1277 of 2014 | 02 Jul 2014",
    attachment: { label: "Arnesh_Kumar_vs_State_of_Bihar_2014.pdf", path: "references/Arnesh_Kumar_vs_State_of_Bihar_2014.pdf" }
  },
  {
    id: "ref-pwdva-2005",
    title: "Protection of Women from Domestic Violence Act, 2005",
    citation: "Act No. 43 of 2005 | India Code",
    attachment: {
      label: "Protection_of_Women_from_Domestic_Violence_Act_2005.pdf",
      path: "references/Protection_of_Women_from_Domestic_Violence_Act_2005.pdf"
    }
  },
  {
    id: "ref-pwdv-rules-2006",
    title: "Protection of Women from Domestic Violence Rules, 2006",
    citation: "G.S.R. 644(E) | 17 Oct 2006 | India Code",
    attachment: {
      label: "Protection_of_Women_from_Domestic_Violence_Rules_2006.pdf",
      path: "references/Protection_of_Women_from_Domestic_Violence_Rules_2006.pdf"
    }
  }
];

const requiredExhibitEntries = [
  {
    id: "exh-drive-01",
    date: "2026-04-22",
    exhibitNo: "Exh-1",
    description: "Google Drive Exhibit Link 1",
    attachment: {
      label: "Exhibit Link 1",
      path: "https://drive.google.com/file/d/11IqytDrFTgKneoas27F9Fgu0-MhbktMm/view?usp=sharing"
    }
  },
  {
    id: "exh-drive-02",
    date: "2026-04-22",
    exhibitNo: "Exh-2",
    description: "Google Drive Exhibit Link 2",
    attachment: {
      label: "Exhibit Link 2",
      path: "https://drive.google.com/file/d/1ZEh-qWqk0znfqsGZSYb1hRspwk5P_cRu/view?usp=sharing"
    }
  },
  {
    id: "exh-drive-03",
    date: "2026-04-22",
    exhibitNo: "Exh-3",
    description: "Google Drive Exhibit Link 3",
    attachment: {
      label: "Exhibit Link 3",
      path: "https://drive.google.com/file/d/1XDFZLkNo3efD2mchFqHsmPoecZN07rYj/view?usp=sharing"
    }
  },
  {
    id: "exh-drive-04",
    date: "2026-04-22",
    exhibitNo: "Exh-4",
    description: "Google Drive Exhibit Link 4",
    attachment: {
      label: "Exhibit Link 4",
      path: "https://drive.google.com/file/d/1OKSQRLKlQHZ1fXTHIoLxbbi_pRoj3reR/view?usp=sharing"
    }
  },
  {
    id: "exh-drive-05",
    date: "2026-04-22",
    exhibitNo: "Exh-5",
    description: "Google Drive Exhibit Link 5",
    attachment: {
      label: "Exhibit Link 5",
      path: "https://drive.google.com/file/d/1AR9yaQAisyTq_gdFeVCUuGE9Y_T5k2-r/view?usp=sharing"
    }
  },
  {
    id: "exh-drive-06",
    date: "2026-04-22",
    exhibitNo: "Exh-6",
    description: "Google Drive Exhibit Link 6",
    attachment: {
      label: "Exhibit Link 6",
      path: "https://drive.google.com/file/d/1AR9yaQAisyTq_gdFeVCUuGE9Y_T5k2-r/view?usp=sharing"
    }
  },
  {
    id: "exh-drive-07",
    date: "2026-04-22",
    exhibitNo: "Exh-7",
    description: "Google Drive Exhibit Link 7",
    attachment: {
      label: "Exhibit Link 7",
      path: "https://drive.google.com/file/d/1s5s7gOcdrgGSnNA5HUGCKRLDDRJY1F5U/view?usp=sharing"
    }
  },
  {
    id: "exh-drive-08",
    date: "2026-04-22",
    exhibitNo: "Exh-8",
    description: "Google Drive Exhibit Link 8",
    attachment: {
      label: "Exhibit Link 8",
      path: "https://drive.google.com/file/d/1VWq0BETAuop-xPDukX0j01UGNwBhakoP/view?usp=sharing"
    }
  },
  {
    id: "exh-drive-09",
    date: "2026-04-22",
    exhibitNo: "Exh-9",
    description: "Google Drive Exhibit Link 9",
    attachment: {
      label: "Exhibit Link 9",
      path: "https://drive.google.com/file/d/1YlvDYEAJmMJ9iSPl3TqiKn2MKKOLCU3y/view?usp=sharing"
    }
  },
  {
    id: "exh-drive-10",
    date: "2026-04-22",
    exhibitNo: "Exh-10",
    description: "Google Drive Exhibit Link 10",
    attachment: {
      label: "Exhibit Link 10",
      path: "https://drive.google.com/file/d/1_dUEX8pOXHA4PNFF-Z9RXKsUN7kqxQZ_/view?usp=sharing"
    }
  },
  {
    id: "exh-drive-11",
    date: "2026-04-22",
    exhibitNo: "Exh-11",
    description: "Google Drive Exhibit Link 11",
    attachment: {
      label: "Exhibit Link 11",
      path: "https://drive.google.com/file/d/1qqUQf5Ek06SqMffetK8VXdBliczKS8dq/view?usp=sharing"
    }
  }
];

const requiredPaymentEntries = [
  {
    id: "pay-drive-01",
    date: "2026-04-22",
    amount: 0,
    mode: "Proof Link",
    reference: "Payment Link 1",
    notes: "Google Drive payment proof",
    attachment: {
      label: "Payment Link 1",
      path: "https://drive.google.com/file/d/1MUS9pK2js-x9953OhoVIPiqHXdnp_II8/view?usp=sharing"
    }
  },
  {
    id: "pay-drive-02",
    date: "2026-04-22",
    amount: 0,
    mode: "Proof Link",
    reference: "Payment Link 2",
    notes: "Google Drive payment proof",
    attachment: {
      label: "Payment Link 2",
      path: "https://drive.google.com/file/d/1nL7rxFvjdSW5ZMobj9Dk1irhljniHRji/view?usp=sharing"
    }
  },
  {
    id: "pay-drive-03",
    date: "2026-04-22",
    amount: 0,
    mode: "Proof Link",
    reference: "Payment Link 3",
    notes: "Google Drive payment proof",
    attachment: {
      label: "Payment Link 3",
      path: "https://drive.google.com/file/d/1AcLYCnImcIBIUH7wfDH4L-1xhdnB8ifA/view?usp=sharing"
    }
  },
  {
    id: "pay-drive-04",
    date: "2026-04-22",
    amount: 0,
    mode: "Proof Link",
    reference: "Payment Link 4",
    notes: "Google Drive payment proof",
    attachment: {
      label: "Payment Link 4",
      path: "https://drive.google.com/file/d/1vrixTcY_rRvGQsVuIgN-r1E57YrSBWS0/view?usp=sharing"
    }
  },
  {
    id: "pay-drive-05",
    date: "2026-04-22",
    amount: 0,
    mode: "Proof Link",
    reference: "Payment Link 5",
    notes: "Google Drive payment proof",
    attachment: {
      label: "Payment Link 5",
      path: "https://drive.google.com/file/d/1krKpEhP3bW3XEU5Uxg6-w50o8i2mN77W/view?usp=sharing"
    }
  },
  {
    id: "pay-drive-06",
    date: "2026-04-22",
    amount: 0,
    mode: "Proof Link",
    reference: "Payment Link 6",
    notes: "Google Drive payment proof",
    attachment: {
      label: "Payment Link 6",
      path: "https://drive.google.com/file/d/1BsQFqpmlVngSH-1e1ShY8JZkb2Uhnyco/view?usp=sharing"
    }
  }
];

const requiredCertifiedCopyEntries = [
  {
    id: "copy-drive-01",
    appliedDate: "2026-04-22",
    documentName: "Certified Copy Link 1",
    applicationNo: "-",
    receivedDate: "",
    notes: "Google Drive certified copy",
    attachment: {
      label: "Certified Copy 1",
      path: "https://drive.google.com/file/d/11IqytDrFTgKneoas27F9Fgu0-MhbktMm/view?usp=drive_link"
    }
  },
  {
    id: "copy-drive-02",
    appliedDate: "2026-04-22",
    documentName: "Certified Copy Link 2",
    applicationNo: "-",
    receivedDate: "",
    notes: "Google Drive certified copy",
    attachment: {
      label: "Certified Copy 2",
      path: "https://drive.google.com/file/d/1ZEh-qWqk0znfqsGZSYb1hRspwk5P_cRu/view?usp=drive_link"
    }
  },
  {
    id: "copy-drive-03",
    appliedDate: "2026-04-22",
    documentName: "Certified Copy Link 3",
    applicationNo: "-",
    receivedDate: "",
    notes: "Google Drive certified copy",
    attachment: {
      label: "Certified Copy 3",
      path: "https://drive.google.com/file/d/1OKSQRLKlQHZ1fXTHIoLxbbi_pRoj3reR/view?usp=drive_link"
    }
  },
  {
    id: "copy-drive-04",
    appliedDate: "2026-04-22",
    documentName: "Certified Copy Link 4",
    applicationNo: "-",
    receivedDate: "",
    notes: "Google Drive certified copy",
    attachment: {
      label: "Certified Copy 4",
      path: "https://drive.google.com/file/d/1XDFZLkNo3efD2mchFqHsmPoecZN07rYj/view?usp=drive_link"
    }
  },
  {
    id: "copy-drive-05",
    appliedDate: "2026-04-22",
    documentName: "Certified Copy Link 5",
    applicationNo: "-",
    receivedDate: "",
    notes: "Google Drive certified copy",
    attachment: {
      label: "Certified Copy 5",
      path: "https://drive.google.com/file/d/1s5s7gOcdrgGSnNA5HUGCKRLDDRJY1F5U/view?usp=drive_link"
    }
  },
  {
    id: "copy-drive-06",
    appliedDate: "2026-04-22",
    documentName: "Certified Copy Link 6",
    applicationNo: "-",
    receivedDate: "",
    notes: "Google Drive certified copy",
    attachment: {
      label: "Certified Copy 6",
      path: "https://drive.google.com/file/d/1VWq0BETAuop-xPDukX0j01UGNwBhakoP/view?usp=drive_link"
    }
  },
  {
    id: "copy-drive-07",
    appliedDate: "2026-04-22",
    documentName: "Certified Copy Link 7",
    applicationNo: "-",
    receivedDate: "",
    notes: "Google Drive certified copy",
    attachment: {
      label: "Certified Copy 7",
      path: "https://drive.google.com/file/d/1q0XtDFIVR00GLK0mkVi8GdCMXC0rSfJQ/view?usp=drive_link"
    }
  },
  {
    id: "copy-drive-08",
    appliedDate: "2026-04-22",
    documentName: "Certified Copy Link 8",
    applicationNo: "-",
    receivedDate: "",
    notes: "Google Drive certified copy",
    attachment: {
      label: "Certified Copy 8",
      path: "https://drive.google.com/file/d/1AR9yaQAisyTq_gdFeVCUuGE9Y_T5k2-r/view?usp=drive_link"
    }
  },
  {
    id: "copy-drive-09",
    appliedDate: "2026-04-22",
    documentName: "Certified Copy Link 9",
    applicationNo: "-",
    receivedDate: "",
    notes: "Google Drive certified copy",
    attachment: {
      label: "Certified Copy 9",
      path: "https://drive.google.com/file/d/1YlvDYEAJmMJ9iSPl3TqiKn2MKKOLCU3y/view?usp=drive_link"
    }
  },
  {
    id: "copy-drive-10",
    appliedDate: "2026-04-22",
    documentName: "Certified Copy Link 10",
    applicationNo: "-",
    receivedDate: "",
    notes: "Google Drive certified copy",
    attachment: {
      label: "Certified Copy 10",
      path: "https://drive.google.com/file/d/1qqUQf5Ek06SqMffetK8VXdBliczKS8dq/view?usp=drive_link"
    }
  },
  {
    id: "copy-drive-11",
    appliedDate: "2026-04-22",
    documentName: "Certified Copy Link 11",
    applicationNo: "-",
    receivedDate: "",
    notes: "Google Drive certified copy",
    attachment: {
      label: "Certified Copy 11",
      path: "https://drive.google.com/file/d/1AR9yaQAisyTq_gdFeVCUuGE9Y_T5k2-r/view?usp=drive_link"
    }
  },
  {
    id: "copy-drive-12",
    appliedDate: "2026-04-22",
    documentName: "Certified Copy Link 12",
    applicationNo: "-",
    receivedDate: "",
    notes: "Google Drive certified copy",
    attachment: {
      label: "Certified Copy 12",
      path: "https://drive.google.com/file/d/1_dUEX8pOXHA4PNFF-Z9RXKsUN7kqxQZ_/view?usp=drive_link"
    }
  }
];

const defaultData = {
  profile: {
    role: "Respondent (Husband)",
    court: "Chief Judicial Magistrate, Pune",
    caseType: "PWDVA Application - Domestic Violence Act",
    filingNumber: "135625/2023",
    registrationNumber: "795/2023",
    cnrNumber: "MHPU041356362023",
    eFilingNumber: "AMH20230019705C202300023",
    filingDate: "2023-12-28",
    registrationDate: "2023-12-28",
    eFilingDate: "2023-12-28",
    firstHearingDate: "2024-01-12",
    currentStage: "Evidence",
    judge: "7th Joint Civil Judge J.D. and JMFC, Pune",
    acts: ["Protection of Women from Domestic Violence Act"],
    sections: ["12", "17", "18", "20", "22", "23"],
    petitioner: ["Priyanka Prashant Jadhav"],
    petitionerAdvocate: "Shaikh Amjad Sultan",
    respondents: [
      "Prashant Ramchandra Jadhav",
      "Ramchandra Jadhav",
      "Prafulla Ramchandra Jadhav",
      "Pratibha Ramchandra Jadhav",
      "Surekha Ramchandra Jadhav"
    ],
    respondentAdvocate: "Varu Kushal Manoj"
  },
  hearings: [
    { businessDate: "2026-03-18", hearingDate: "2026-04-27", purpose: "Evidence", judge: "7th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-12-20", hearingDate: "2026-03-18", purpose: "Evidence", judge: "7th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-11-13", hearingDate: "2025-12-20", purpose: "Evidence", judge: "7th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-10-29", hearingDate: "2025-11-13", purpose: "Evidence", judge: "7th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-09-17", hearingDate: "2025-10-29", purpose: "Evidence", judge: "7th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-09-08", hearingDate: "2025-09-17", purpose: "Evidence", judge: "7th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-08-19", hearingDate: "2025-09-08", purpose: "Evidence", judge: "7th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-07-15", hearingDate: "2025-08-19", purpose: "Evidence", judge: "7th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-06-23", hearingDate: "2025-07-15", purpose: "Evidence", judge: "7th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-06-17", hearingDate: "2025-06-23", purpose: "Evidence", judge: "7th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-06-09", hearingDate: "2025-06-17", purpose: "Evidence", judge: "7th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-06-02", hearingDate: "2025-06-09", purpose: "Evidence", judge: "7th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-05-02", hearingDate: "2025-06-02", purpose: "Evidence", judge: "7th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-04-25", hearingDate: "2025-05-02", purpose: "Evidence", judge: "7th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-04-17", hearingDate: "2025-04-25", purpose: "Evidence", judge: "7th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-04-11", hearingDate: "2025-04-17", purpose: "Evidence", judge: "7th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-03-20", hearingDate: "2025-04-11", purpose: "Evidence", judge: "4th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-03-15", hearingDate: "2025-03-20", purpose: "Evidence", judge: "4th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-02-15", hearingDate: "2025-03-15", purpose: "Evidence", judge: "4th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-02-06", hearingDate: "2025-02-15", purpose: "Evidence", judge: "4th Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-01-09", hearingDate: "2025-02-06", purpose: "Evidence", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2025-01-07", hearingDate: "2025-01-09", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-12-26", hearingDate: "2025-01-07", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-12-02", hearingDate: "2024-12-26", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-11-28", hearingDate: "2024-12-02", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-11-12", hearingDate: "2024-11-28", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-10-25", hearingDate: "2024-11-12", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-10-18", hearingDate: "2024-10-25", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-10-04", hearingDate: "2024-10-18", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-09-25", hearingDate: "2024-10-04", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-09-20", hearingDate: "2024-09-25", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-09-03", hearingDate: "2024-09-20", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-08-30", hearingDate: "2024-09-03", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-08-16", hearingDate: "2024-08-30", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-08-01", hearingDate: "2024-08-16", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-07-03", hearingDate: "2024-08-01", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-07-02", hearingDate: "2024-07-03", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-04-30", hearingDate: "2024-07-02", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-04-06", hearingDate: "2024-04-30", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-04-02", hearingDate: "2024-04-06", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-03-15", hearingDate: "2024-04-02", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-02-27", hearingDate: "2024-03-15", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-01-25", hearingDate: "2024-02-27", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" },
    { businessDate: "2024-01-12", hearingDate: "2024-01-25", purpose: "Unready Board", judge: "3rd Joint Civil Judge J.D. and JMFC, Pune" }
  ],
  orders: [
    {
      orderNumber: 1,
      date: "2025-01-09",
      details: "Maintenance Order",
      attachments: [{ label: "Maintenenace Order 09012025.pdf", path: "attachments/Maintenenace Order 09012025.pdf" }]
    },
    {
      orderNumber: 2,
      date: "2025-02-15",
      details: "Application - Distrace Warrant",
      attachments: [{ label: "Application - Distrace Warrant 15022025.pdf", path: "attachments/Application - Distrace Warrant 15022025.pdf" }]
    },
    {
      orderNumber: 3,
      date: "2025-03-15",
      details: "Bailable Warrant Issuance Application",
      attachments: [{ label: "Bailabale Warrant Issuance Application 15032025.pdf", path: "attachments/Bailabale Warrant Issuance Application 15032025.pdf" }]
    },
    {
      orderNumber: 4,
      date: "2025-03-18",
      details: "Issue NBW",
      attachments: [{ label: "Issue NBW 18032025.pdf", path: "attachments/Issue NBW 18032025.pdf" }]
    },
    {
      orderNumber: 5,
      date: "2025-03-20",
      details: "Application for Arrest Warrant",
      attachments: [{ label: "Application for Arrest Warrant 20032025.pdf", path: "attachments/Application for Arrest Warrant 20032025.pdf" }]
    },
    {
      orderNumber: 6,
      date: "2025-05-02",
      details: "Arrest Warrant Issue",
      attachments: [{ label: "Arrest Warrant Issue 02052025.pdf", path: "attachments/Arrest Warrant Issue 02052025.pdf" }]
    },
    {
      orderNumber: 7,
      date: "2025-06-02",
      details: "Arrest Warrant Against Respondent",
      attachments: [{ label: "Arrest Warrant against Respondent 02062025.pdf", path: "attachments/Arrest Warrant against Respondent 02062025.pdf" }]
    },
    {
      orderNumber: 8,
      date: "2025-10-29",
      details: "Application Allowed As Prayed",
      attachments: [{ label: "Application allowed as prayed 29102025.pdf", path: "attachments/Application allowed as prayed 29102025.pdf" }]
    },
    { orderNumber: 9, date: "2026-03-18", details: "Order on Exhibit", attachments: [] }
  ],
  exhibits: structuredClone(requiredExhibitEntries),
  certifiedCopies: structuredClone(requiredCertifiedCopyEntries),
  references: [
    {
      id: "ref-rajnesh-neha",
      title: "Rajnesh v. Neha",
      citation: "Supreme Court of India | Criminal Appeal No. 730 of 2020 | 04 Nov 2020",
      attachment: { label: "Rajnesh_vs_Neha_2020.pdf", path: "references/Rajnesh_vs_Neha_2020.pdf" }
    },
    {
      id: "ref-aditi-jitesh-2023",
      title: "Aditi alias Mithi v. Jitesh Sharma",
      citation: "2023 INSC 981 | Criminal Appeal No. 3446 of 2023 | 06 Nov 2023",
      attachment: {
        label: "Aditi_alias_Mithi_vs_Jitesh_Sharma_2023_INSC_981.pdf",
        path: "references/Aditi_alias_Mithi_vs_Jitesh_Sharma_2023_INSC_981.pdf"
      }
    },
    {
      id: "ref-arnesh-bihar",
      title: "Arnesh Kumar v. State of Bihar",
      citation: "Supreme Court of India | Criminal Appeal No. 1277 of 2014 | 02 Jul 2014",
      attachment: { label: "Arnesh_Kumar_vs_State_of_Bihar_2014.pdf", path: "references/Arnesh_Kumar_vs_State_of_Bihar_2014.pdf" }
    },
    {
      id: "ref-pwdva-2005",
      title: "Protection of Women from Domestic Violence Act, 2005",
      citation: "Act No. 43 of 2005 | India Code",
      attachment: {
        label: "Protection_of_Women_from_Domestic_Violence_Act_2005.pdf",
        path: "references/Protection_of_Women_from_Domestic_Violence_Act_2005.pdf"
      }
    },
    {
      id: "ref-pwdv-rules-2006",
      title: "Protection of Women from Domestic Violence Rules, 2006",
      citation: "G.S.R. 644(E) | 17 Oct 2006 | India Code",
      attachment: {
        label: "Protection_of_Women_from_Domestic_Violence_Rules_2006.pdf",
        path: "references/Protection_of_Women_from_Domestic_Violence_Rules_2006.pdf"
      }
    }
  ],
  maintenancePayments: structuredClone(requiredPaymentEntries),
  daughterGifts: [],
  tasks: [
    { id: "t1", text: "Call advocate before next hearing", dueDate: "2026-04-25", done: false },
    { id: "t2", text: "Keep all exhibits and identity documents ready", dueDate: "2026-04-26", done: false },
    { id: "t3", text: "Prepare short factual timeline", dueDate: "2026-04-24", done: false }
  ],
  notes: [
    {
      id: "n1",
      title: "Case diary started",
      body: "Imported case details from eCourts screenshots. Update after every hearing.",
      createdAt: "2026-04-22T09:00:00.000Z"
    }
  ]
};

let state = load();

function normalizeOrderAttachments(orders) {
  const incoming = Array.isArray(orders)
    ? orders.map((order, index) => ({
        orderNumber: Number(order.orderNumber) || index + 1,
        date: order.date,
        details: order.details || "Order on Exhibit",
        attachments: Array.isArray(order.attachments) ? order.attachments : []
      }))
    : [];

  requiredOrderDocuments.forEach((required) => {
    const existing = incoming.find((order) => order.date === required.date);
    if (!existing) {
      incoming.push({
        orderNumber: incoming.length + 1,
        date: required.date,
        details: required.details,
        attachments: [required.attachment]
      });
      return;
    }

    const hasDoc = existing.attachments.some((item) => item.path === required.attachment.path);
    if (!hasDoc) {
      existing.attachments.push(required.attachment);
    }

    if (!existing.details || existing.details === "Order on Exhibit") {
      existing.details = required.details;
    }
  });

  incoming.sort((a, b) => {
    const dateDiff = new Date(a.date) - new Date(b.date);
    if (dateDiff !== 0) return dateDiff;
    return a.orderNumber - b.orderNumber;
  });

  incoming.forEach((order, index) => {
    order.orderNumber = index + 1;
  });

  return incoming;
}

function normalizeReferences(references) {
  const incoming = Array.isArray(references)
    ? references
        .filter((item) => item && item.attachment && item.attachment.path)
        .map((item, index) => ({
          id: item.id || `ref-${Date.now()}-${index}`,
          title: item.title || "Untitled Judgement",
          citation: item.citation || "-",
          attachment: {
            label: item.attachment.label || "View PDF",
            path: item.attachment.path
          }
        }))
    : [];

  requiredReferenceJudgements.forEach((required) => {
    const exists = incoming.some((item) => item.attachment.path === required.attachment.path);
    if (!exists) {
      incoming.push(structuredClone(required));
    }
  });

  return incoming;
}

function normalizeMaintenancePayments(payments) {
  const incoming = Array.isArray(payments)
    ? payments
        .filter((item) => item && item.date)
        .map((item, index) => ({
          id: item.id || `pay-${index + 1}`,
          date: item.date,
          amount: Number(item.amount) || 0,
          mode: item.mode || "-",
          reference: item.reference || "-",
          notes: item.notes || "-",
          attachment: item.attachment && item.attachment.path
            ? {
                label: item.attachment.label || "View File",
                path: item.attachment.path
              }
            : null
        }))
    : [];

  requiredPaymentEntries.forEach((required) => {
    const exists = incoming.some((item) => item.id === required.id);
    if (!exists) {
      incoming.push(structuredClone(required));
    }
  });

  incoming.sort((a, b) => new Date(b.date) - new Date(a.date));
  return incoming;
}

function normalizeDaughterGifts(gifts) {
  const incoming = Array.isArray(gifts)
    ? gifts
        .filter((item) => item && item.date && item.item)
        .map((item, index) => ({
          id: item.id || `gift-${index + 1}`,
          date: item.date,
          item: item.item,
          amount: Number(item.amount) || 0,
          occasion: item.occasion || "-",
          notes: item.notes || "-"
        }))
    : [];

  incoming.sort((a, b) => new Date(b.date) - new Date(a.date));
  return incoming;
}

function normalizeExhibits(exhibits) {
  const incoming = Array.isArray(exhibits)
    ? exhibits
        .filter((item) => item && item.date && item.exhibitNo && item.description)
        .map((item, index) => ({
          id: item.id || `exh-${index + 1}`,
          date: item.date,
          exhibitNo: item.exhibitNo,
          description: item.description,
          attachment: item.attachment && item.attachment.path
            ? {
                label: item.attachment.label || "View File",
                path: item.attachment.path
              }
            : null
        }))
    : [];

  requiredExhibitEntries.forEach((required) => {
    const exists = incoming.some((item) => item.id === required.id);
    if (!exists) {
      incoming.push(structuredClone(required));
    }
  });

  incoming.sort((a, b) => new Date(b.date) - new Date(a.date));
  return incoming;
}

function normalizeCertifiedCopies(copies) {
  const incoming = Array.isArray(copies)
    ? copies
        .filter((item) => item && item.appliedDate && item.documentName)
        .map((item, index) => ({
          id: item.id || `copy-${index + 1}`,
          appliedDate: item.appliedDate,
          documentName: item.documentName,
          applicationNo: item.applicationNo || "-",
          receivedDate: item.receivedDate || "",
          notes: item.notes || "-",
          attachment: item.attachment && item.attachment.path
            ? {
                label: item.attachment.label || "View File",
                path: item.attachment.path
              }
            : null
        }))
    : [];

  requiredCertifiedCopyEntries.forEach((required) => {
    const exists = incoming.some((item) => item.id === required.id);
    if (!exists) {
      incoming.push(structuredClone(required));
    }
  });

  incoming.sort((a, b) => new Date(b.appliedDate) - new Date(a.appliedDate));
  return incoming;
}

function migrateState(data) {
  const migrated = structuredClone(data);
  migrated.orders = normalizeOrderAttachments(migrated.orders);
  migrated.references = normalizeReferences(migrated.references);
  migrated.maintenancePayments = normalizeMaintenancePayments(migrated.maintenancePayments);
  migrated.daughterGifts = normalizeDaughterGifts(migrated.daughterGifts);
  migrated.exhibits = normalizeExhibits(migrated.exhibits);
  migrated.certifiedCopies = normalizeCertifiedCopies(migrated.certifiedCopies);
  return migrated;
}

function load() {
  try {
    const raw = localStorage.getItem(storageKey);
    return raw ? migrateState(JSON.parse(raw)) : migrateState(defaultData);
  } catch {
    return migrateState(defaultData);
  }
}

function save() {
  localStorage.setItem(storageKey, JSON.stringify(state));
}

function toIndianDate(isoDate) {
  if (!isoDate) return "-";
  const d = new Date(isoDate);
  if (Number.isNaN(d.getTime())) return isoDate;
  return new Intl.DateTimeFormat("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  }).format(d);
}

function formatCurrencyINR(amount) {
  const numericAmount = Number(amount);
  if (!Number.isFinite(numericAmount)) return "-";
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(numericAmount);
}

function getNextHearing() {
  const today = new Date();
  const futureHearings = state.hearings
    .map((h) => ({ ...h, dt: new Date(h.hearingDate) }))
    .filter((h) => !Number.isNaN(h.dt.getTime()) && h.dt >= new Date(today.toDateString()))
    .sort((a, b) => a.dt - b.dt);
  return futureHearings[0] || null;
}

function daysUntil(dateString) {
  const now = new Date();
  const target = new Date(dateString);
  const diffMs = target - new Date(now.toDateString());
  return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
}

function renderSummary() {
  const next = getNextHearing();
  const pendingTasks = state.tasks.filter((t) => !t.done).length;
  const totalMaintenancePaid = (state.maintenancePayments || []).reduce((sum, payment) => sum + (Number(payment.amount) || 0), 0);
  const totalGiftEntries = (state.daughterGifts || []).length;
  const totalExhibits = (state.exhibits || []).length;
  const totalCertifiedCopies = (state.certifiedCopies || []).length;
  const summary = [
    { label: "Next Hearing", value: next ? toIndianDate(next.hearingDate) : "Not available" },
    {
      label: "Days Left",
      value: next ? `${daysUntil(next.hearingDate)} day(s)` : "-",
      alert: next ? daysUntil(next.hearingDate) <= 7 : false
    },
    { label: "Case Stage", value: state.profile.currentStage || "-" },
    { label: "Pending Tasks", value: String(pendingTasks) },
    { label: "Hearings Logged", value: String(state.hearings.length) },
    { label: "Orders Logged", value: String(state.orders.length) },
    { label: "Maintenance Paid", value: formatCurrencyINR(totalMaintenancePaid) },
    { label: "Daughter Gifts", value: String(totalGiftEntries) },
    { label: "Exhibits Logged", value: String(totalExhibits) },
    { label: "Certified Copies", value: String(totalCertifiedCopies) }
  ];

  const summaryGrid = document.getElementById("summaryGrid");
  summaryGrid.innerHTML = summary
    .map(
      (item) => `
        <article class="stat ${item.alert ? "alert" : ""}">
          <p class="label">${item.label}</p>
          <p class="value">${item.value}</p>
        </article>
      `
    )
    .join("");

  document.getElementById("roleBadge").textContent = state.profile.role;
}

function renderMeta() {
  const mapping = [
    ["Court", state.profile.court],
    ["Case Type", state.profile.caseType],
    ["Filing Number", state.profile.filingNumber],
    ["Registration Number", state.profile.registrationNumber],
    ["CNR Number", state.profile.cnrNumber],
    ["e-Filing Number", state.profile.eFilingNumber],
    ["First Hearing", toIndianDate(state.profile.firstHearingDate)],
    ["Current Judge", state.profile.judge],
    ["Petitioner", state.profile.petitioner.join(", ")],
    ["Petitioner Advocate", state.profile.petitionerAdvocate],
    ["Respondents", state.profile.respondents.join(", ")],
    ["Respondent Advocate", state.profile.respondentAdvocate]
  ];

  const caseMeta = document.getElementById("caseMeta");
  caseMeta.innerHTML = "";

  const template = document.getElementById("metaRowTemplate");
  mapping.forEach(([key, value]) => {
    const clone = template.content.cloneNode(true);
    clone.querySelector(".meta-key").textContent = key;
    clone.querySelector(".meta-value").textContent = value || "-";
    caseMeta.appendChild(clone);
  });

  document.getElementById("actsWrap").innerHTML = `
    <strong>Acts & Sections</strong>
    <p>${state.profile.acts.join(", ")}</p>
    <p>Sections: ${state.profile.sections.join(", ")}</p>
  `;
}

function renderHearings() {
  const body = document.getElementById("hearingTable");
  const sorted = [...state.hearings].sort((a, b) => new Date(b.hearingDate) - new Date(a.hearingDate));

  body.innerHTML = sorted
    .map(
      (row) => `
      <tr>
        <td>${toIndianDate(row.businessDate)}</td>
        <td>${toIndianDate(row.hearingDate)}</td>
        <td>${row.purpose || "-"}</td>
        <td>${row.judge || "-"}</td>
        <td><button class="mini" data-delete-hearing="${row.hearingDate}-${row.businessDate}">Delete</button></td>
      </tr>
    `
    )
    .join("");
}

function renderOrders() {
  const body = document.getElementById("orderTable");
  const sorted = [...state.orders].sort((a, b) => a.orderNumber - b.orderNumber);

  body.innerHTML = sorted
    .map(
      (row) => {
        const attachmentHtml = row.attachments?.length
          ? `<div class="doc-links">${row.attachments
              .map(
                (attachment) =>
                  `<a class="doc-link" href="${encodeURI(attachment.path)}" target="_blank" rel="noopener">${attachment.label}</a>`
              )
              .join("")}</div>`
          : "-";

        return `
      <tr>
        <td>${row.orderNumber}</td>
        <td>${toIndianDate(row.date)}</td>
        <td>${row.details}</td>
        <td>${attachmentHtml}</td>
        <td><button class="mini" data-delete-order="${row.orderNumber}">Delete</button></td>
      </tr>
    `;
      }
    )
    .join("");
}

function renderExhibits() {
  const body = document.getElementById("exhibitTable");
  const rows = [...(state.exhibits || [])].sort((a, b) => new Date(b.date) - new Date(a.date));

  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="5" class="empty">No exhibits logged yet.</td></tr>';
    return;
  }

  body.innerHTML = rows
    .map((row) => {
      const attachmentHtml = row.attachment?.path
        ? `<a class="doc-link" href="${encodeURI(row.attachment.path)}" target="_blank" rel="noopener">${row.attachment.label || "View File"}</a>`
        : "-";

      return `
      <tr>
        <td>${toIndianDate(row.date)}</td>
        <td>${row.exhibitNo}</td>
        <td>${row.description}</td>
        <td>${attachmentHtml}</td>
        <td><button class="mini" data-delete-exhibit="${row.id}">Delete</button></td>
      </tr>
    `;
    })
    .join("");
}

function renderCertifiedCopies() {
  const body = document.getElementById("copyTable");
  const rows = [...(state.certifiedCopies || [])].sort((a, b) => new Date(b.appliedDate) - new Date(a.appliedDate));

  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="7" class="empty">No certified copy records yet.</td></tr>';
    return;
  }

  body.innerHTML = rows
    .map((row) => {
      const attachmentHtml = row.attachment?.path
        ? `<a class="doc-link" href="${encodeURI(row.attachment.path)}" target="_blank" rel="noopener">${row.attachment.label || "View File"}</a>`
        : "-";

      return `
      <tr>
        <td>${toIndianDate(row.appliedDate)}</td>
        <td>${row.documentName}</td>
        <td>${row.applicationNo || "-"}</td>
        <td>${row.receivedDate ? toIndianDate(row.receivedDate) : "-"}</td>
        <td>${attachmentHtml}</td>
        <td>${row.notes || "-"}</td>
        <td><button class="mini" data-delete-copy="${row.id}">Delete</button></td>
      </tr>
    `;
    })
    .join("");
}

function renderReferences() {
  const body = document.getElementById("referenceTable");
  const rows = [...(state.references || [])];

  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="4" class="empty">No reference judgements yet.</td></tr>';
    return;
  }

  body.innerHTML = rows
    .map(
      (row) => `
      <tr>
        <td>${row.title}</td>
        <td>${row.citation || "-"}</td>
        <td>
          <a class="doc-link" href="${encodeURI(row.attachment.path)}" target="_blank" rel="noopener">
            ${row.attachment.label}
          </a>
        </td>
        <td><button class="mini" data-delete-reference="${row.id}">Delete</button></td>
      </tr>
    `
    )
    .join("");
}

function renderMaintenancePayments() {
  const body = document.getElementById("paymentTable");
  const rows = [...(state.maintenancePayments || [])].sort((a, b) => new Date(b.date) - new Date(a.date));

  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="7" class="empty">No maintenance payment records yet.</td></tr>';
    return;
  }

  body.innerHTML = rows
    .map(
      (row) => {
        const attachmentHtml = row.attachment?.path
          ? `<a class="doc-link" href="${encodeURI(row.attachment.path)}" target="_blank" rel="noopener">${row.attachment.label || "View File"}</a>`
          : "-";

        return `
      <tr>
        <td>${toIndianDate(row.date)}</td>
        <td>${formatCurrencyINR(row.amount)}</td>
        <td>${row.mode || "-"}</td>
        <td>${row.reference || "-"}</td>
        <td>${attachmentHtml}</td>
        <td>${row.notes || "-"}</td>
        <td><button class="mini" data-delete-payment="${row.id}">Delete</button></td>
      </tr>
    `;
      }
    )
    .join("");
}

function renderDaughterGifts() {
  const body = document.getElementById("giftTable");
  const rows = [...(state.daughterGifts || [])].sort((a, b) => new Date(b.date) - new Date(a.date));

  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="6" class="empty">No daughter gift records yet.</td></tr>';
    return;
  }

  body.innerHTML = rows
    .map(
      (row) => `
      <tr>
        <td>${toIndianDate(row.date)}</td>
        <td>${row.item}</td>
        <td>${formatCurrencyINR(row.amount)}</td>
        <td>${row.occasion || "-"}</td>
        <td>${row.notes || "-"}</td>
        <td><button class="mini" data-delete-gift="${row.id}">Delete</button></td>
      </tr>
    `
    )
    .join("");
}

function renderTasks() {
  const list = document.getElementById("taskList");

  if (!state.tasks.length) {
    list.innerHTML = '<li class="empty">No tasks yet.</li>';
    return;
  }

  const sorted = [...state.tasks].sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate));
  list.innerHTML = sorted
    .map(
      (task) => `
      <li class="task-item ${task.done ? "done" : ""}">
        <div class="task-main">
          <input type="checkbox" ${task.done ? "checked" : ""} data-toggle-task="${task.id}" />
          <span class="task-text">${task.text}</span>
        </div>
        <div>
          <span class="deadline">${toIndianDate(task.dueDate)}</span>
          <button class="mini" data-delete-task="${task.id}">Delete</button>
        </div>
      </li>
    `
    )
    .join("");
}

function renderNotes() {
  const wrap = document.getElementById("notesList");
  const sorted = [...state.notes].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  if (!sorted.length) {
    wrap.innerHTML = '<div class="empty">No notes yet.</div>';
    return;
  }

  wrap.innerHTML = sorted
    .map(
      (note) => `
      <article class="note-card">
        <p class="note-meta">${toIndianDate(note.createdAt)}</p>
        <h4 class="note-title">${note.title}</h4>
        <p class="note-body">${note.body}</p>
        <button class="mini" data-delete-note="${note.id}">Delete</button>
      </article>
    `
    )
    .join("");
}

function renderAll() {
  renderSummary();
  renderMeta();
  renderHearings();
  renderOrders();
  renderExhibits();
  renderCertifiedCopies();
  renderMaintenancePayments();
  renderDaughterGifts();
  renderReferences();
  renderTasks();
  renderNotes();
}

function addHearing() {
  const hearingDate = document.getElementById("hearingDate").value;
  const hearingPurpose = document.getElementById("hearingPurpose").value.trim();

  if (!hearingDate || !hearingPurpose) return;

  state.hearings.push({
    businessDate: new Date().toISOString().slice(0, 10),
    hearingDate,
    purpose: hearingPurpose,
    judge: state.profile.judge
  });

  document.getElementById("hearingDate").value = "";
  document.getElementById("hearingPurpose").value = "";
  save();
  renderAll();
}

function addOrder() {
  const orderDate = document.getElementById("orderDate").value;
  const orderTitle = document.getElementById("orderTitle").value.trim();

  if (!orderDate || !orderTitle) return;

  const orderNumber = (state.orders.at(-1)?.orderNumber || 0) + 1;
  state.orders.push({ orderNumber, date: orderDate, details: orderTitle, attachments: [] });

  document.getElementById("orderDate").value = "";
  document.getElementById("orderTitle").value = "";
  save();
  renderAll();
}

function addExhibit() {
  const exhibitDate = document.getElementById("exhibitDate").value;
  const exhibitNo = document.getElementById("exhibitNo").value.trim();
  const exhibitDesc = document.getElementById("exhibitDesc").value.trim();
  const exhibitPath = document.getElementById("exhibitPath").value.trim();

  if (!exhibitDate || !exhibitNo || !exhibitDesc) return;

  const attachment = exhibitPath
    ? {
        label: exhibitPath.split("/").at(-1) || "View File",
        path: exhibitPath
      }
    : null;

  state.exhibits = state.exhibits || [];
  state.exhibits.push({
    id: `exh-${Date.now()}`,
    date: exhibitDate,
    exhibitNo,
    description: exhibitDesc,
    attachment
  });

  document.getElementById("exhibitDate").value = "";
  document.getElementById("exhibitNo").value = "";
  document.getElementById("exhibitDesc").value = "";
  document.getElementById("exhibitPath").value = "";
  save();
  renderAll();
}

function addCertifiedCopy() {
  const appliedDate = document.getElementById("copyAppliedDate").value;
  const documentName = document.getElementById("copyDocName").value.trim();
  const applicationNo = document.getElementById("copyApplicationNo").value.trim();
  const receivedDate = document.getElementById("copyReceivedDate").value;
  const copyPath = document.getElementById("copyPath").value.trim();
  const copyNotes = document.getElementById("copyNotes").value.trim();

  if (!appliedDate || !documentName) return;

  const attachment = copyPath
    ? {
        label: copyPath.split("/").at(-1) || "View File",
        path: copyPath
      }
    : null;

  state.certifiedCopies = state.certifiedCopies || [];
  state.certifiedCopies.push({
    id: `copy-${Date.now()}`,
    appliedDate,
    documentName,
    applicationNo: applicationNo || "-",
    receivedDate: receivedDate || "",
    notes: copyNotes || "-",
    attachment
  });

  document.getElementById("copyAppliedDate").value = "";
  document.getElementById("copyDocName").value = "";
  document.getElementById("copyApplicationNo").value = "";
  document.getElementById("copyReceivedDate").value = "";
  document.getElementById("copyPath").value = "";
  document.getElementById("copyNotes").value = "";
  save();
  renderAll();
}

function addReference() {
  const refTitle = document.getElementById("refTitle").value.trim();
  const refCitation = document.getElementById("refCitation").value.trim();
  const refPath = document.getElementById("refPath").value.trim();

  if (!refTitle || !refPath) return;

  const fileName = refPath.split("/").at(-1) || "Reference.pdf";
  state.references = state.references || [];
  state.references.push({
    id: `ref-${Date.now()}`,
    title: refTitle,
    citation: refCitation || "-",
    attachment: { label: fileName, path: refPath }
  });

  document.getElementById("refTitle").value = "";
  document.getElementById("refCitation").value = "";
  document.getElementById("refPath").value = "";
  save();
  renderAll();
}

function addPayment() {
  const paymentDate = document.getElementById("paymentDate").value;
  const paymentAmount = Number(document.getElementById("paymentAmount").value);
  const paymentMode = document.getElementById("paymentMode").value.trim();
  const paymentRef = document.getElementById("paymentRef").value.trim();
  const paymentPath = document.getElementById("paymentPath").value.trim();
  const paymentNotes = document.getElementById("paymentNotes").value.trim();

  if (!paymentDate || !Number.isFinite(paymentAmount) || paymentAmount <= 0) return;

  const attachment = paymentPath
    ? {
        label: paymentPath.split("/").at(-1) || "View File",
        path: paymentPath
      }
    : null;

  state.maintenancePayments = state.maintenancePayments || [];
  state.maintenancePayments.push({
    id: `pay-${Date.now()}`,
    date: paymentDate,
    amount: paymentAmount,
    mode: paymentMode || "-",
    reference: paymentRef || "-",
    notes: paymentNotes || "-",
    attachment
  });

  document.getElementById("paymentDate").value = "";
  document.getElementById("paymentAmount").value = "";
  document.getElementById("paymentMode").value = "";
  document.getElementById("paymentRef").value = "";
  document.getElementById("paymentPath").value = "";
  document.getElementById("paymentNotes").value = "";
  save();
  renderAll();
}

function addGift() {
  const giftDate = document.getElementById("giftDate").value;
  const giftItem = document.getElementById("giftItem").value.trim();
  const rawAmount = document.getElementById("giftAmount").value;
  const giftOccasion = document.getElementById("giftOccasion").value.trim();
  const giftNotes = document.getElementById("giftNotes").value.trim();

  if (!giftDate || !giftItem) return;

  const amount = rawAmount === "" ? 0 : Number(rawAmount);
  if (!Number.isFinite(amount) || amount < 0) return;

  state.daughterGifts = state.daughterGifts || [];
  state.daughterGifts.push({
    id: `gift-${Date.now()}`,
    date: giftDate,
    item: giftItem,
    amount,
    occasion: giftOccasion || "-",
    notes: giftNotes || "-"
  });

  document.getElementById("giftDate").value = "";
  document.getElementById("giftItem").value = "";
  document.getElementById("giftAmount").value = "";
  document.getElementById("giftOccasion").value = "";
  document.getElementById("giftNotes").value = "";
  save();
  renderAll();
}

function addTask() {
  const taskText = document.getElementById("taskText").value.trim();
  const taskDate = document.getElementById("taskDate").value;

  if (!taskText || !taskDate) return;

  state.tasks.push({
    id: `t-${Date.now()}`,
    text: taskText,
    dueDate: taskDate,
    done: false
  });

  document.getElementById("taskText").value = "";
  document.getElementById("taskDate").value = "";
  save();
  renderAll();
}

function addNote() {
  const title = document.getElementById("noteTitle").value.trim();
  const body = document.getElementById("noteBody").value.trim();

  if (!title || !body) return;

  state.notes.push({
    id: `n-${Date.now()}`,
    title,
    body,
    createdAt: new Date().toISOString()
  });

  document.getElementById("noteTitle").value = "";
  document.getElementById("noteBody").value = "";
  save();
  renderAll();
}

function bindEvents() {
  document.getElementById("addHearingBtn").addEventListener("click", addHearing);
  document.getElementById("addOrderBtn").addEventListener("click", addOrder);
  document.getElementById("addExhibitBtn").addEventListener("click", addExhibit);
  document.getElementById("addCopyBtn").addEventListener("click", addCertifiedCopy);
  document.getElementById("addPaymentBtn").addEventListener("click", addPayment);
  document.getElementById("addGiftBtn").addEventListener("click", addGift);
  document.getElementById("addReferenceBtn").addEventListener("click", addReference);
  document.getElementById("addTaskBtn").addEventListener("click", addTask);
  document.getElementById("addNoteBtn").addEventListener("click", addNote);

  document.querySelectorAll(".tab").forEach((tabButton) => {
    tabButton.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
      document.querySelectorAll(".tab-content").forEach((c) => c.classList.remove("active"));

      tabButton.classList.add("active");
      document.getElementById(`tab-${tabButton.dataset.tab}`).classList.add("active");
    });
  });

  document.body.addEventListener("click", (event) => {
    const hearingKey = event.target.getAttribute("data-delete-hearing");
    if (hearingKey) {
      state.hearings = state.hearings.filter((h) => `${h.hearingDate}-${h.businessDate}` !== hearingKey);
      save();
      renderAll();
      return;
    }

    const orderNo = event.target.getAttribute("data-delete-order");
    if (orderNo) {
      state.orders = state.orders.filter((o) => String(o.orderNumber) !== orderNo);
      save();
      renderAll();
      return;
    }

    const exhibitId = event.target.getAttribute("data-delete-exhibit");
    if (exhibitId) {
      state.exhibits = (state.exhibits || []).filter((exhibit) => exhibit.id !== exhibitId);
      save();
      renderAll();
      return;
    }

    const copyId = event.target.getAttribute("data-delete-copy");
    if (copyId) {
      state.certifiedCopies = (state.certifiedCopies || []).filter((copy) => copy.id !== copyId);
      save();
      renderAll();
      return;
    }

    const refId = event.target.getAttribute("data-delete-reference");
    if (refId) {
      state.references = (state.references || []).filter((r) => r.id !== refId);
      save();
      renderAll();
      return;
    }

    const paymentId = event.target.getAttribute("data-delete-payment");
    if (paymentId) {
      state.maintenancePayments = (state.maintenancePayments || []).filter((payment) => payment.id !== paymentId);
      save();
      renderAll();
      return;
    }

    const giftId = event.target.getAttribute("data-delete-gift");
    if (giftId) {
      state.daughterGifts = (state.daughterGifts || []).filter((gift) => gift.id !== giftId);
      save();
      renderAll();
      return;
    }

    const taskId = event.target.getAttribute("data-delete-task");
    if (taskId) {
      state.tasks = state.tasks.filter((t) => t.id !== taskId);
      save();
      renderAll();
      return;
    }

    const noteId = event.target.getAttribute("data-delete-note");
    if (noteId) {
      state.notes = state.notes.filter((n) => n.id !== noteId);
      save();
      renderAll();
    }
  });

  document.body.addEventListener("change", (event) => {
    const taskId = event.target.getAttribute("data-toggle-task");
    if (!taskId) return;
    const task = state.tasks.find((t) => t.id === taskId);
    if (task) {
      task.done = Boolean(event.target.checked);
      save();
      renderAll();
    }
  });

  document.getElementById("exportBtn").addEventListener("click", () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `lawyers-diary-backup-${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(link.href);
  });

  document.getElementById("importInput").addEventListener("change", async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const content = await file.text();
      const parsed = JSON.parse(content);
      if (!parsed.profile || !parsed.hearings || !parsed.orders) {
        alert("Invalid backup file format.");
        return;
      }
      state = migrateState(parsed);
      save();
      renderAll();
      alert("Backup imported successfully.");
    } catch {
      alert("Could not import file.");
    }
  });

  document.getElementById("resetBtn").addEventListener("click", () => {
    state = migrateState(defaultData);
    save();
    renderAll();
  });
}

function init() {
  bindEvents();
  renderAll();
}

init();
